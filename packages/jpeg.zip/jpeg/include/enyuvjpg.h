/************************************************************************/
/* store yuv4:2:0 to jpeg file                                          */
/*  -outfile: filename of jpeg file outputed.                           */
/************************************************************************/
void encode_yuv_jpg(char *outfile, 
										unsigned char *srcY, 
										unsigned char *srcU, 
										unsigned char *srcV,
										int image_width, 
										int image_heigth);