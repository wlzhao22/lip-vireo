/*
 * example.c
 *
 * This file illustrates how to use the IJG code as a subroutine library
 * to read or write JPEG image files.  You should look at this code in
 * conjunction with the documentation file libjpeg.doc.
 *
 * This code will not do anything useful as-is, but it may be helpful as a
 * skeleton for constructing routines that call the JPEG library.
 *
 * We present these routines in the same coding style used in the JPEG code
 * (ANSI function definitions, etc); but you are of course free to code your
 * routines in a different style if you prefer.
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * Include file for users of JPEG library.
 * You will need to have included system headers that define at least
 * the typedefs FILE and size_t before you can include jpeglib.h.
 * (stdio.h is sufficient on ANSI-conforming systems.)
 * You may also wish to include "jerror.h".
 */

#include "jpeglib.h"  //ylj

/*
 * <setjmp.h> is used for the optional error recovery mechanism shown in
 * the second part of the example.
 */

#include <setjmp.h>



/******************** JPEG COMPRESSION SAMPLE INTERFACE *******************/

/* This half of the example shows how to feed data into the JPEG compressor.
 * We present a minimal version that does not worry about refinements such
 * as error recovery (the JPEG code will just exit() if it gets an error).
 */


/*
 * IMAGE DATA FORMATS:
 *
 * The standard input image format is a rectangular array of pixels, with
 * each pixel having the same number of "component" values (color channels).
 * Each pixel row is an array of JSAMPLEs (which typically are unsigned chars).
 * If you are working with color data, then the color values for each pixel
 * must be adjacent in the row; for example, R,G,B,R,G,B,R,G,B,... for 24-bit
 * RGB color.
 *
 * For this example, we'll assume that this data structure matches the way
 * our application has stored the image in memory, so we can just pass a
 * pointer to our image buffer.  In particular, let's say that the image is
 * RGB color and is described by:
 */

//extern JSAMPLE * image_buffer;	/* Points to large array of R,G,B-order data */
//extern int image_height;	/* Number of rows in image */
//extern int image_width;		/* Number of columns in image */
//JSAMPLE * image_buffer;	/* Points to large array of R,G,B-order data */  //ylj
//int image_height;	/* Number of rows in image */
//int image_width;		/* Number of columns in image */


/*
 * Sample routine for JPEG compression.  We assume that the target file name
 * and a compression quality factor are passed in.
 */
GLOBAL(void)
write_JPEG_file (char * filename, int quality, JSAMPLE * image_buffer, int image_height, int image_width)
{

  /* This struct contains the JPEG compression parameters and pointers to
   * working space (which is allocated as needed by the JPEG library).
   * It is possible to have several such structures, representing multiple
   * compression/decompression processes, in existence at once.  We refer
   * to any one struct (and its associated working data) as a "JPEG object".
   */
  struct jpeg_compress_struct cinfo;
  /* This struct represents a JPEG error handler.  It is declared separately
   * because applications often want to supply a specialized error handler
   * (see the second half of this file for an example).  But here we just
   * take the easy way out and use the standard error handler, which will
   * print a message on stderr and call exit() if compression fails.
   * Note that this struct must live as long as the main JPEG parameter
   * struct, to avoid dangling-pointer problems.
   */
  struct jpeg_error_mgr jerr;
  /* More stuff */
  FILE * outfile;		/* target file */
  JSAMPROW row_pointer[1];	/* pointer to JSAMPLE row[s] */
  int row_stride;		/* physical row width in image buffer */

  /* Step 1: allocate and initialize JPEG compression object */

  /* We have to set up the error handler first, in case the initialization
   * step fails.  (Unlikely, but it could happen if you are out of memory.)
   * This routine fills in the contents of struct jerr, and returns jerr's
   * address which we place into the link field in cinfo.
   */
  cinfo.err = jpeg_std_error(&jerr);
  /* Now we can initialize the JPEG compression object. */
  jpeg_create_compress(&cinfo);

  /* Step 2: specify data destination (eg, a file) */
  /* Note: steps 2 and 3 can be done in either order. */

  /* Here we use the library-supplied code to send compressed data to a
   * stdio stream.  You can also write your own code to do something else.
   * VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
   * requires it in order to write binary files.
   */
  if ((outfile = fopen(filename, "wb")) == NULL) {
    fprintf(stderr, "can't open %s\n", filename);
    exit(1);
  }
  jpeg_stdio_dest(&cinfo, outfile);

  /* Step 3: set parameters for compression */

  /* First we supply a description of the input image.
   * Four fields of the cinfo struct must be filled in:
   */
  cinfo.image_width = image_width; 	/* image width and height, in pixels */
  cinfo.image_height = image_height;
  cinfo.input_components = 3;		/* # of color components per pixel */
  cinfo.in_color_space = JCS_RGB; 	/* colorspace of input image */
  /* Now use the library's routine to set default compression parameters.
   * (You must set at least cinfo.in_color_space before calling this,
   * since the defaults depend on the source color space.)
   */
  jpeg_set_defaults(&cinfo);
  /* Now you can set any non-default parameters you wish to.
   * Here we just illustrate the use of quality (quantization table) scaling:
   */
  jpeg_set_quality(&cinfo, quality, TRUE /* limit to baseline-JPEG values */);

  /* Step 4: Start compressor */

  /* TRUE ensures that we will write a complete interchange-JPEG file.
   * Pass TRUE unless you are very sure of what you're doing.
   */
  jpeg_start_compress(&cinfo, TRUE);

  /* Step 5: while (scan lines remain to be written) */
  /*           jpeg_write_scanlines(...); */

  /* Here we use the library's state variable cinfo.next_scanline as the
   * loop counter, so that we don't have to keep track ourselves.
   * To keep things simple, we pass one scanline per call; you can pass
   * more if you wish, though.
   */
  row_stride = image_width * 3;	/* JSAMPLEs per row in image_buffer */

  while (cinfo.next_scanline < cinfo.image_height) {
    /* jpeg_write_scanlines expects an array of pointers to scanlines.
     * Here the array is only one element long, but you could pass
     * more than one scanline at a time if that's more convenient.
     */
    row_pointer[0] = & image_buffer[cinfo.next_scanline * row_stride];
    (void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
  }

  /* Step 6: Finish compression */

  jpeg_finish_compress(&cinfo);
  /* After finish_compress, we can close the output file. */
  fclose(outfile);

  /* Step 7: release JPEG compression object */

  /* This is an important step since it will release a good deal of memory. */
  jpeg_destroy_compress(&cinfo);

  /* And we're done! */
}


/*
 * SOME FINE POINTS:
 *
 * In the above loop, we ignored the return value of jpeg_write_scanlines,
 * which is the number of scanlines actually written.  We could get away
 * with this because we were only relying on the value of cinfo.next_scanline,
 * which will be incremented correctly.  If you maintain additional loop
 * variables then you should be careful to increment them properly.
 * Actually, for output to a stdio stream you needn't worry, because
 * then jpeg_write_scanlines will write all the lines passed (or else exit
 * with a fatal error).  Partial writes can only occur if you use a data
 * destination module that can demand suspension of the compressor.
 * (If you don't know what that's for, you don't need it.)
 *
 * If the compressor requires full-image buffers (for entropy-coding
 * optimization or a multi-scan JPEG file), it will create temporary
 * files for anything that doesn't fit within the maximum-memory setting.
 * (Note that temp files are NOT needed if you use the default parameters.)
 * On some systems you may need to set up a signal handler to ensure that
 * temporary files are deleted if the program is interrupted.  See libjpeg.doc.
 *
 * Scanlines MUST be supplied in top-to-bottom order if you want your JPEG
 * files to be compatible with everyone else's.  If you cannot readily read
 * your data in that order, you'll need an intermediate array to hold the
 * image.  See rdtarga.c or rdbmp.c for examples of handling bottom-to-top
 * source data using the JPEG code's internal virtual-array mechanisms.
 */



/******************** JPEG DECOMPRESSION SAMPLE INTERFACE *******************/

/* This half of the example shows how to read data from the JPEG decompressor.
 * It's a bit more refined than the above, in that we show:
 *   (a) how to modify the JPEG library's standard error-reporting behavior;
 *   (b) how to allocate workspace using the library's memory manager.
 *
 * Just to make this example a little different from the first one, we'll
 * assume that we do not intend to put the whole image into an in-memory
 * buffer, but to send it line-by-line someplace else.  We need a one-
 * scanline-high JSAMPLE array as a work buffer, and we will let the JPEG
 * memory manager allocate it for us.  This approach is actually quite useful
 * because we don't need to remember to deallocate the buffer separately: it
 * will go away automatically when the JPEG object is cleaned up.
 */


/*
 * ERROR HANDLING:
 *
 * The JPEG library's standard error handler (jerror.c) is divided into
 * several "methods" which you can override individually.  This lets you
 * adjust the behavior without duplicating a lot of code, which you might
 * have to update with each future release.
 *
 * Our example here shows how to override the "error_exit" method so that
 * control is returned to the library's caller when a fatal error occurs,
 * rather than calling exit() as the standard error_exit method does.
 *
 * We use C's setjmp/longjmp facility to return control.  This means that the
 * routine which calls the JPEG library must first execute a setjmp() call to
 * establish the return point.  We want the replacement error_exit to do a
 * longjmp().  But we need to make the setjmp buffer accessible to the
 * error_exit routine.  To do this, we make a private extension of the
 * standard JPEG error handler object.  (If we were using C++, we'd say we
 * were making a subclass of the regular error handler.)
 *
 * Here's the extended error handler struct:
 */

//struct my_error_mgr {
//  struct jpeg_error_mgr pub;	/* "public" fields */

//  jmp_buf setjmp_buffer;	/* for return to caller */
//};

//typedef struct my_error_mgr * my_error_ptr;

/*
 * Here's the routine that will replace the standard error_exit method:
 */

//METHODDEF(void)
//my_error_exit (j_common_ptr cinfo)
//{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
//  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We could postpone this until after returning, if we chose. */
//  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
//  longjmp(myerr->setjmp_buffer, 1);
//}


/*
 * Sample routine for JPEG decompression.  We assume that the source file name
 * is passed in.  We want to return 1 on success, 0 on error.
 */


/************************************************************************/
/* Interpolation for CrCb in 4:2:0                                      */
/************************************************************************/
void Cx_Interpolation(unsigned char *Cx_dest, unsigned char *Cx_org, int image_width, int image_height)
{
	int j,i;
	int iWidth_Cx  = image_width >> 1;
	int iHeight_Cx = image_height >> 1;
	int image_offset_Y = 0;
	int image_offset_X = 0;
	int Cx_offset_Y = 0;
	int Cx_offset_X = 0;
	for (j=0; j<iHeight_Cx; j++)
	{

		image_offset_X  = 0;
		for (i=0; i<iWidth_Cx; i++)
		{
			image_offset_X = (i<<1);
			Cx_offset_X    = i;
			  Cx_dest[image_offset_Y + image_offset_X                  ]
			= Cx_dest[image_offset_Y + image_offset_X + 1              ]
			= Cx_dest[image_offset_Y + image_offset_X + image_width    ]
			= Cx_dest[image_offset_Y + image_offset_X + image_width + 1]	= Cx_org[Cx_offset_Y + i];
		}
		image_offset_Y += (image_width << 1);
		Cx_offset_Y    += iWidth_Cx;
	}
}

/************************************************************************/
/* YCbCr to RGB for one pixel                                           */
/************************************************************************/
#define clip(x)  ((x)>255 \
                 ? 255    \
                 : (x)<0  \
                   ? 0    \
                   : x )
//_inline  //by wanlei zhao
void YCbCr_to_RGB(unsigned char Y,
												 unsigned char Cb,
												 unsigned char Cr,
												 unsigned char * R,
												 unsigned char * G,
												 unsigned char * B )
{

	/*
	*R = (unsigned char)clip(1.164 * (Y-16) +                  1.596*(Cr-128) );
	*G = (unsigned char)clip(1.164 * (Y-16) - 0.392*(Cb-128) - 0.813*(Cr-128) );
	*B = (unsigned char)clip(1.164 * (Y-16) + 2.017*(Cb-128)                  );
	*/
	int tempY = 1192 * (Y-16);
	int tempCr = Cr-128;
	int tempCb = Cb-128;

	*R = (unsigned char)clip((tempY +              1634*tempCr) >>10);
	*G = (unsigned char)clip((tempY -  401*tempCb - 833*tempCr) >>10);
	*B = (unsigned char)clip((tempY + 2065*tempCb             ) >>10);
}

/************************************************************************/
/* YUV 4:2:0 to RGB                                                     */
/* The R G B Components are given as                                    */
/*  frame0: RRR...RGGG...GBBB...B                                       */
/*  frame1: RRR...RGGG...GBBB...B                                       */
/*  .............................                                       */
/************************************************************************/
void YUV420_to_RGB(unsigned char * image_Y,
							unsigned char * image_Cb,
							unsigned char * image_Cr,
							unsigned char * RGBImage_buffer,
							int image_width,
							int image_height)
{
	unsigned char *temp_Cb, *temp_Cr;
	int i,j;
	int offset_Y=0;
	int image_size = image_height * image_width;
	int offset_G = image_size;
	int offset_B = image_size << 1;

	temp_Cb = malloc(image_size);
	if ( temp_Cb == NULL )
	{
		printf("%memory allocation for YV12_to_RGB24() failed");
		exit(0);
	}
	temp_Cr = malloc(image_size);
	if (temp_Cr == NULL)
	{
		free(temp_Cb);
	}

	Cx_Interpolation(temp_Cb, image_Cb, image_width, image_height);
	Cx_Interpolation(temp_Cr, image_Cr, image_width, image_height);

	for (j=0; j<image_height; j++)
	{
		for (i=0; i<image_width; i++)
		{
			int offset = offset_Y + i;
			YCbCr_to_RGB(image_Y[offset],
				           temp_Cb[offset],
									 temp_Cr[offset],
									 &RGBImage_buffer[offset           ],
									 &RGBImage_buffer[offset + offset_G],
									 &RGBImage_buffer[offset + offset_B]
									 );
		}
		offset_Y += image_width;
	}

	if (temp_Cb != NULL)
		free(temp_Cb);
	if (temp_Cr != NULL)
		free(temp_Cr);
}


/************************************************************************/
/* YUV 4:2:0 to RGB                                                     */
/* The R G B Components are given as                                    */
/*  frame0: RGB...RGB...RGB                                             */
/*  frame1: RGB...RGB...RGB                                             */
/*  .......................                                             */
/************************************************************************/
void YV12_to_RGB24(unsigned char * image_Y,
							unsigned char * image_Cb,
							unsigned char * image_Cr,
							unsigned char * image_buffer,
							int image_width,
							int image_height)
{
	unsigned char *temp_Cb, *temp_Cr;
	int i,j;
	int offset_Y=0;
	temp_Cb = malloc(image_height * image_width);
	if ( temp_Cb == NULL )
	{
		printf("%memory allocation for YV12_to_RGB24() failed");
		exit(0);
	}
	temp_Cr = malloc(image_height * image_width);
	if (temp_Cr == NULL)
	{
		free(temp_Cb);
	}

	Cx_Interpolation(temp_Cb, image_Cb, image_width, image_height);
	Cx_Interpolation(temp_Cr, image_Cr, image_width, image_height);

	for (j=0; j<image_height; j++)
	{
		for (i=0; i<image_width; i++)
		{
			int offset = offset_Y + i;
			YCbCr_to_RGB(image_Y[offset],
				           temp_Cb[offset],
									 temp_Cr[offset],
									 &image_buffer[offset*3    ],
									 &image_buffer[offset*3 + 1],
									 &image_buffer[offset*3 + 2]
									 );
		}
		offset_Y += image_width;
	}

	if (temp_Cb != NULL)
		free(temp_Cb);
	if (temp_Cr != NULL)
		free(temp_Cr);
}


/*
 * SOME FINE POINTS:
 *
 * In the above code, we ignored the return value of jpeg_read_scanlines,
 * which is the number of scanlines actually read.  We could get away with
 * this because we asked for only one line at a time and we weren't using
 * a suspending data source.  See libjpeg.doc for more info.
 *
 * We cheated a bit by calling alloc_sarray() after jpeg_start_decompress();
 * we should have done it beforehand to ensure that the space would be
 * counted against the JPEG max_memory setting.  In some systems the above
 * code would risk an out-of-memory error.  However, in general we don't
 * know the output image dimensions before jpeg_start_decompress(), unless we
 * call jpeg_calc_output_dimensions().  See libjpeg.doc for more about this.
 *
 * Scanlines are returned in the same order as they appear in the JPEG file,
 * which is standardly top-to-bottom.  If you must emit data bottom-to-top,
 * you can use one of the virtual arrays provided by the JPEG memory manager
 * to invert the data.  See wrbmp.c for an example.
 *
 * As with compression, some operating modes may require temporary files.
 * On some systems you may need to set up a signal handler to ensure that
 * temporary files are deleted if the program is interrupted.  See libjpeg.doc.
 */
/************************************************************************/
/* store yuv4:2:0 to jpeg file                                          */
/*  -outfile: filename of jpeg file outputed.                           */
/************************************************************************/
void encode_yuv_jpg(char *outfile,
										unsigned char *srcY,
										unsigned char *srcU,
										unsigned char *srcV,
										int image_width,
										int image_heigth)
{
	int quality = 75; //quality control factor for jpeg
	unsigned char *image_buffer_RGB = malloc(image_heigth * image_width * 3);
	if (image_buffer_RGB == NULL)
	{
		printf("memory allocation in store_yuv_jpg() failed!");
	}

	YV12_to_RGB24(srcY, srcU, srcV, image_buffer_RGB, image_width, image_heigth);
 	write_JPEG_file (outfile, quality, image_buffer_RGB, image_heigth, image_width);

	free(image_buffer_RGB);
}



